=begin
  
program to ask personal info and store it in a hash

ask for a list of relatives names and store them in an array

use the each method to print out the keys and values  
=end

=begin
  
write your own sorting method
it should sort the items in an array in alphabetical or numerical order
assume that the array will hold integers and strings  
end