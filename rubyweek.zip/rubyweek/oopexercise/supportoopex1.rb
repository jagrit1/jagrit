if dob !=""
@dob = Date.parse(dob)
else
@dob = nil
end

def add_email (email)
	@emails << email
end

def fullname
	"#{@firstname.capitalize} #{@lastname}"
end

