#Readme file for the personalproject

I. Description
==============
object oriented programming practice and tdd for development of application


II. File list
==============
Gemfile  
Gemfile.lock  
person.rb  
Rakefile  
readme.md  
spec/
person_Spec.rb
spec_helper.rb
